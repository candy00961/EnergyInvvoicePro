
// Initialize charts when the document is ready
document.addEventListener('DOMContentLoaded', function() {
    // Initialize charts
    const deviceChart = new Chart(document.getElementById('deviceChart'), {
        type: 'bar',
        data: {
            labels: [],
            datasets: [{
                label: 'Device Consumption (kWh)',
                data: [],
                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Consumption (kWh)'
                    }
                }
            }
        }
    });

    const consumptionChart = new Chart(document.getElementById('consumptionChart'), {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Consumption Trend',
                data: [],
                fill: false,
                borderColor: 'rgb(75, 192, 192)',
                tension: 0.1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Total Consumption (kWh)'
                    }
                }
            }
        }
    });

    function updateDashboardData() {
        fetch('/api/dashboard-data')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update device chart
                    const deviceData = data.data.consumption;
                    deviceChart.data.labels = Object.keys(deviceData).map(key => `Device ${key.slice(0,8)}`);
                    deviceChart.data.datasets[0].data = Object.values(deviceData).map(v => parseFloat(v) || 0);
                    deviceChart.update();

                    // Update consumption trend chart
                    const trendData = data.data.trend;
                    if (trendData && trendData.length > 0) {
                        console.log('Trend data:', trendData);  // Debug log
                        consumptionChart.data.labels = trendData.map(item => item.date);
                        consumptionChart.data.datasets[0].data = trendData.map(item => parseFloat(item.consumption) || 0);
                        consumptionChart.options.scales.y.beginAtZero = true;
                        consumptionChart.update();
                    } else {
                        console.log('No trend data available');  // Debug log
                    }

                    // Update recent invoices table
                    const invoicesTable = document.querySelector('table tbody');
                    if (invoicesTable && data.data.recent_invoices) {
                        invoicesTable.innerHTML = data.data.recent_invoices.map(invoice => `
                            <tr>
                                <td>${invoice.invoice_number}</td>
                                <td>Device ${invoice.device_id}</td>
                                <td>$${invoice.total_amount.toFixed(2)}</td>
                                <td>
                                    <span class="badge bg-${invoice.status === 'paid' ? 'success' : 'warning'}">
                                        ${invoice.status}
                                    </span>
                                </td>
                            </tr>
                        `).join('');
                    }
                } else {
                    console.error('Failed to fetch dashboard data:', data.message);
                }
            })
            .catch(error => {
                console.error('Error fetching dashboard data:', error);
                deviceChart.update();
                consumptionChart.update();
            });
    }

    // Handle generate invoices button click
    const generateInvoicesBtn = document.getElementById('generateInvoices');
    if (generateInvoicesBtn) {
        generateInvoicesBtn.addEventListener('click', function() {
            this.disabled = true;
            this.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Generating...';

            fetch('/api/generate-invoices', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Successfully generated invoices!');
                    updateDashboardData();
                } else {
                    alert('Error generating invoices: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Failed to generate invoices. Please try again.');
            })
            .finally(() => {
                this.disabled = false;
                this.innerHTML = 'Generate Invoices';
            });
        });
    }

    // Initial update
    updateDashboardData();

    // Refresh dashboard data every 30 seconds
    setInterval(updateDashboardData, 30000);
});
