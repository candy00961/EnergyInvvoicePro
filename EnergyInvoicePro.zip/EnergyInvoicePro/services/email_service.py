import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
import logging

logger = logging.getLogger(__name__)

class EmailService:
    def __init__(self, smtp_server: str, smtp_port: int, username: str, password: str):
        self.smtp_server = smtp_server
        self.smtp_port = smtp_port
        self.username = username
        self.password = password

    def send_invoice(self, recipient: str, invoice_number: str, pdf_path: str) -> bool:
        """
        Send invoice email with PDF attachment
        """
        try:
            msg = MIMEMultipart()
            msg['Subject'] = f'Invoice #{invoice_number}'
            msg['From'] = self.username
            msg['To'] = recipient

            # Email body
            body = f"""
            Dear Customer,

            Please find attached your invoice #{invoice_number}.

            Thank you for your business.

            Best regards,
            RVE Team
            """
            msg.attach(MIMEText(body, 'plain'))

            # Attach PDF
            with open(pdf_path, 'rb') as f:
                pdf = MIMEApplication(f.read(), _subtype='pdf')
                pdf.add_header('Content-Disposition', 'attachment', 
                             filename=f'invoice_{invoice_number}.pdf')
                msg.attach(pdf)

            # Send email
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.username, self.password)
                server.send_message(msg)

            return True

        except Exception as e:
            logger.error(f"Failed to send invoice email: {str(e)}")
            return False
