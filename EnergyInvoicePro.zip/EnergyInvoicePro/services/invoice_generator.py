import os
from datetime import datetime
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
import logging

logger = logging.getLogger(__name__)

class InvoiceGenerator:
    def __init__(self, output_dir: str):
        self.output_dir = output_dir
        # Create output directory if it doesn't exist
        os.makedirs(output_dir, exist_ok=True)
        self.styles = getSampleStyleSheet()
        # Add custom style for company info
        self.styles.add(ParagraphStyle(
            name='CompanyInfo',
            fontSize=10,
            spaceAfter=12,
            leading=14
        ))

    def generate_invoice(self, invoice_data: dict) -> str:
        """
        Generate PDF invoice using ReportLab with EV charging specific format
        """
        try:
            logger.info(f"Generating invoice {invoice_data['invoice_number']}")

            filename = f"invoice_{invoice_data['invoice_number']}.pdf"
            filepath = os.path.join(self.output_dir, filename)

            # Create document
            doc = SimpleDocTemplate(
                filepath,
                pagesize=letter,
                rightMargin=72,
                leftMargin=72,
                topMargin=72,
                bottomMargin=72
            )

            elements = []

            # Header
            elements.append(Paragraph("EV Station Invoice Statement", self.styles['Heading1']))
            elements.append(Spacer(1, 20))

            # Company Information
            company_info = [
                ["Syndicate Name:", invoice_data.get('syndicate_name', '')],
                ["Address:", invoice_data.get('company_address', '')],
                ["Phone:", invoice_data.get('company_phone', '')],
                ["Email:", invoice_data.get('company_email', '')],
                ["Website:", invoice_data.get('company_website', '')]
            ]

            table = Table(company_info, colWidths=[2*inch, 4*inch])
            table.setStyle(TableStyle([
                ('ALIGN', (0,0), (-1,-1), 'LEFT'),
                ('FONTNAME', (0,0), (-1,-1), 'Helvetica'),
                ('FONTSIZE', (0,0), (-1,-1), 10),
                ('BOTTOMPADDING', (0,0), (-1,-1), 8),
            ]))
            elements.append(table)
            elements.append(Spacer(1, 20))

            # Invoice Details
            elements.append(Paragraph("Invoice Details", self.styles['Heading2']))
            invoice_info = [
                ["Invoice Number:", invoice_data['invoice_number']],
                ["Date:", datetime.now().strftime("%Y-%m-%d")],
                ["Billing Period:", f"{invoice_data['billing_period_start']} to {invoice_data['billing_period_end']}"],
                ["Due Date:", invoice_data.get('due_date', '')]
            ]

            table = Table(invoice_info, colWidths=[2*inch, 4*inch])
            table.setStyle(TableStyle([
                ('ALIGN', (0,0), (-1,-1), 'LEFT'),
                ('FONTNAME', (0,0), (-1,-1), 'Helvetica'),
                ('FONTSIZE', (0,0), (-1,-1), 10),
                ('BOTTOMPADDING', (0,0), (-1,-1), 8),
            ]))
            elements.append(table)
            elements.append(Spacer(1, 20))

            # Charging Sessions Table
            elements.append(Paragraph("Electric Vehicle Charging Details", self.styles['Heading2']))
            elements.append(Spacer(1, 12))

            charging_headers = [
                "Date", "Start Time", "End Time", "Duration",
                "kWh", "Rate", "Amount"
            ]
            charging_data = [charging_headers]

            for session in invoice_data.get('charging_sessions', []):
                charging_data.append([
                    session.get('date', ''),
                    session.get('start_time', ''),
                    session.get('end_time', ''),
                    session.get('duration', ''),
                    f"{session.get('kwh', 0):.2f}",
                    f"${session.get('rate', 0):.2f}",
                    f"${session.get('amount', 0):.2f}"
                ])

            table = Table(charging_data, colWidths=[1*inch, 1*inch, 1*inch, 1*inch, 
                                                   1*inch, 1*inch, 1*inch])
            table.setStyle(TableStyle([
                ('ALIGN', (0,0), (-1,-1), 'CENTER'),
                ('FONTNAME', (0,0), (-1,-1), 'Helvetica'),
                ('FONTSIZE', (0,0), (-1,-1), 9),
                ('GRID', (0,0), (-1,-1), 1, colors.black),
                ('BACKGROUND', (0,0), (-1,0), colors.grey),
                ('TEXTCOLOR', (0,0), (-1,0), colors.whitesmoke),
                ('ALIGN', (-2,-1), (-1,-1), 'RIGHT'),
            ]))
            elements.append(table)
            elements.append(Spacer(1, 20))

            # Summary
            elements.append(Paragraph("Summary", self.styles['Heading2']))
            summary_data = [
                ["Total kWh Consumed:", f"{invoice_data.get('total_kwh', 0):.2f} kWh"],
                ["Rate per kWh:", f"${invoice_data.get('rate', 0):.2f}"],
                ["Total Amount:", f"${invoice_data.get('total_amount', 0):.2f}"]
            ]

            table = Table(summary_data, colWidths=[2*inch, 2*inch])
            table.setStyle(TableStyle([
                ('ALIGN', (0,0), (-1,-1), 'LEFT'),
                ('FONTNAME', (0,0), (-1,-1), 'Helvetica-Bold'),
                ('FONTSIZE', (0,0), (-1,-1), 10),
                ('ALIGN', (1,0), (1,-1), 'RIGHT'),
            ]))
            elements.append(table)
            elements.append(Spacer(1, 20))

            # Payment Instructions
            elements.append(Paragraph("Payment Instructions", self.styles['Heading3']))
            payment_text = f"""
            Please make payment by {invoice_data.get('due_date', '')}. For questions regarding this invoice,
            please contact us at smp@microbms.com or call our customer service at {invoice_data.get('company_phone', '')}.
            """
            elements.append(Paragraph(payment_text, self.styles['Normal']))

            # Build the PDF
            doc.build(elements)
            logger.info(f"Successfully generated invoice PDF at {filepath}")
            return filepath

        except Exception as e:
            logger.error(f"Failed to generate invoice PDF: {str(e)}")
            raise