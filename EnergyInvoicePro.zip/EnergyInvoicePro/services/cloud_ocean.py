import requests
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

class CloudOceanAPI:
    def __init__(self, api_key: str):
        self.base_url = "https://api.develop.rve.ca"
        self.headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        }

    def get_measuring_point_reads(self, module_uuid: str, measuring_point_uuid: str, 
                                start_date: datetime, end_date: datetime) -> List[Dict]:
        """
        Fetch measuring point reads data from Cloud Ocean platform
        """
        try:
            endpoint = f"{self.base_url}/v1/modules/{module_uuid}/measuring-points/{measuring_point_uuid}/reads"
            params = {
                'start_date': start_date.strftime('%Y-%m-%d'),
                'end_date': end_date.strftime('%Y-%m-%d')
            }

            logger.debug(f"Fetching reads for measuring point {measuring_point_uuid}")
            response = requests.get(endpoint, headers=self.headers, params=params)
            response.raise_for_status()

            data = response.json().get('data', [])
            logger.info(f"Successfully fetched {len(data)} reads for measuring point {measuring_point_uuid}")
            return data

        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching measuring point reads: {str(e)}")
            raise

    def get_measuring_point_cdr(self, module_uuid: str, measuring_point_uuid: str,
                              start_date: datetime, end_date: datetime) -> List[Dict]:
        """
        Fetch measuring point CDR (Charge Detail Record) from Cloud Ocean platform
        """
        try:
            endpoint = f"{self.base_url}/v1/modules/{module_uuid}/measuring-points/{measuring_point_uuid}/cdr"
            params = {
                'start_date': start_date.strftime('%Y-%m-%d'),
                'end_date': end_date.strftime('%Y-%m-%d')
            }

            logger.debug(f"Fetching CDR for measuring point {measuring_point_uuid}")
            response = requests.get(endpoint, headers=self.headers, params=params)
            response.raise_for_status()

            data = response.json().get('data', [])
            logger.info(f"Successfully fetched {len(data)} CDR records for measuring point {measuring_point_uuid}")
            return data

        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching measuring point CDR: {str(e)}")
            raise

    def get_all_measuring_points_data(self, module_uuid: str, measuring_point_uuids: List[str],
                                    start_date: datetime, end_date: datetime) -> Dict[str, Dict]:
        """
        Fetch both reads and CDR data for multiple measuring points
        Returns a dictionary with measuring point UUIDs as keys and their data as values
        """
        data = {}
        for mp_uuid in measuring_point_uuids:
            try:
                logger.info(f"Fetching data for measuring point: {mp_uuid}")
                reads = self.get_measuring_point_reads(module_uuid, mp_uuid, start_date, end_date)
                cdr = self.get_measuring_point_cdr(module_uuid, mp_uuid, start_date, end_date)

                data[mp_uuid] = {
                    'reads': reads,
                    'cdr': cdr
                }

                logger.info(f"Successfully fetched data for measuring point: {mp_uuid}")
                logger.debug(f"Read count: {len(reads)}, CDR count: {len(cdr)}")

            except Exception as e:
                logger.error(f"Failed to fetch data for measuring point {mp_uuid}: {str(e)}")
                data[mp_uuid] = {'reads': [], 'cdr': [], 'error': str(e)}

        return data

    def get_module_consumption(self, module_uuid: str, measuring_point_uuids: List[str],
                             start_date: datetime, end_date: datetime) -> Dict[str, float]:
        """
        Calculate total consumption for each measuring point in the module
        Returns a dictionary with measuring point UUIDs as keys and their total consumption as values
        """
        # Only fetch and use real data from API
        consumption_data = {}
        try:
            all_data = self.get_all_measuring_points_data(module_uuid, measuring_point_uuids, 
                                                         start_date, end_date)

            for mp_uuid, data in all_data.items():
                if 'error' in data:
                    consumption_data[mp_uuid] = 0.0
                    logger.warning(f"Error fetching data for measuring point {mp_uuid}")
                    continue

                # Calculate total consumption from reads data
                total_consumption = sum(float(read.get('consumption', 0)) for read in data['reads'])
                consumption_data[mp_uuid] = total_consumption
                logger.info(f"Calculated consumption for {mp_uuid}: {total_consumption} kWh")
        
        except Exception as e:
            logger.error(f"Error fetching consumption data: {str(e)}")
            # Just return empty data on error - no mock data
            for mp_uuid in measuring_point_uuids:
                consumption_data[mp_uuid] = 0.0
            
        return consumption_data

    def validate_measuring_point(self, module_uuid: str, measuring_point_uuid: str) -> bool:
        """
        Validate if a measuring point exists and is accessible
        """
        try:
            endpoint = f"{self.base_url}/v1/modules/{module_uuid}/measuring-points/{measuring_point_uuid}"
            response = requests.get(endpoint, headers=self.headers)
            return response.status_code == 200
        except requests.exceptions.RequestException:
            return False

    def get_device_consumption(self, device_id: str, start_date: datetime, end_date: datetime) -> List[Dict]:
        """
        Fetch consumption data for a specific device from Cloud Ocean platform
        """
        try:
            endpoint = f"{self.base_url}/devices/{device_id}/consumption"
            params = {
                'start_date': start_date.isoformat(),
                'end_date': end_date.isoformat()
            }
            
            response = requests.get(endpoint, headers=self.headers, params=params)
            response.raise_for_status()
            
            return response.json()['data']
        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching consumption data: {str(e)}")
            raise

    def get_device_info(self, device_id: str) -> Dict:
        """
        Fetch device information from Cloud Ocean platform
        """
        try:
            endpoint = f"{self.base_url}/devices/{device_id}"
            response = requests.get(endpoint, headers=self.headers)
            response.raise_for_status()
            
            return response.json()['data']
        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching device info: {str(e)}")
            raise